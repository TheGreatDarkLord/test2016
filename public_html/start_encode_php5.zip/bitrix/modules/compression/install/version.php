<?
$arModuleVersion = array(
	"VERSION" => "16.0.0",
	"VERSION_DATE" => "2015-12-04 16:00:00"
);
?>