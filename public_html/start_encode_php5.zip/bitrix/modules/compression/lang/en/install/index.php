<?
$MESS ['COMPRESSION_MODULE_NAME'] = "Compression";
$MESS ['COMPRESSION_MODULE_DESC'] = "This module enables page compressing to accelerate loading";
$MESS ['COMPRESS_INSTALL_TITLE'] = "Compression module installation";
$MESS ['COMPRESS_UNINSTALL_TITLE'] = "Compression module uninstallation";
?>