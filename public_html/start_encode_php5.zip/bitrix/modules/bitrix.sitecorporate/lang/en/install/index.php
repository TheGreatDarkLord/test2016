<?
$MESS["SCOM_INSTALL_NAME"] = "Corporate Service Site";
$MESS["SCOM_INSTALL_DESCRIPTION"] = "A corporate site wizard to create a model bank corporate site";
$MESS["SCOM_INSTALL_TITLE"] = "Module Installation";
$MESS["SCOM_UNINSTALL_TITLE"] = "Module Uninstallation";
$MESS["SPER_PARTNER"] = "Bitrix, Inc.";
$MESS["PARTNER_URI"] = "http://www.bitrixsoft.com";
?>