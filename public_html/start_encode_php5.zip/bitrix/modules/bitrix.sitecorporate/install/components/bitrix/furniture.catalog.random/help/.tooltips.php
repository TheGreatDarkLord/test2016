<?
$arTooltips = array(
	"IBLOCK_TYPE" => GetMessage("IBLOCK_TYPE_TIP"),
	"IBLOCKS" => GetMessage("IBLOCKS_TIP"),
	"PARENT_SECTION" => GetMessage("PARENT_SECTION_TIP"),
	"DETAIL_URL" => GetMessage("DETAIL_URL_TIP"),
	"CACHE_TYPE" => GetMessage("CACHE_TYPE_TIP"),
	"CACHE_TIME" => GetMessage("CACHE_TIME_TIP"),
);
?>