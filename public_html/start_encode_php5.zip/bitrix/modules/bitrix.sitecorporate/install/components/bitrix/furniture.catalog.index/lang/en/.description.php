<?
$MESS["T_IBLOCK_DESC_CI_LIST"] = "Presentation List";
$MESS["T_IBLOCK_DESC_CI_DESC"] = "Renders the information block's elements or sections in the form of a presentation list.";
$MESS["T_IBLOCK_DESC_CATALOG"] = "Catalog";
?>