<?
$MESS["PORTAL_WIZARD_NAME"] = "Manufacturer Website";
$MESS["PORTAL_WIZARD_DESC"] = "Creates a furniture manufacturer's corporate website";
?>