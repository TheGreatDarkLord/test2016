<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Trade Services");
?>
	<p>Bank provides trade finance services and a gamut of products for both exports and imports. We serve a complete range of customers across varying industries, segments and regions.</p> 
	<h2>Our services include:</h2> 
	<ul><li>Imports; </li> 
	<li>Exports; </li> 
	<li>Bank Guarantees; </li> 
	<li>Collection Services; </li> 
	<li>Trade Advisory Services;</li> 
	<li>Letter of Credit.</li> </ul> 								

 
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>