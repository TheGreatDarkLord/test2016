<?
$MESS ['CT_BSAC_CONFIRM'] = "Confirm";
$MESS ['CT_BSAC_LOGIN'] = "Login";
$MESS ['CT_BSAC_CONFIRM_CODE'] = "Confirmation Code";
?>