<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<h5>New Services</h5>
<dl class="block-list">
	<dt><a href="<?=SITE_DIR?>services/corp/merchant.php">Merchant Services</a></dt>
	<dd>The Merchant Services Program provided by our Bank enables your company to accept any credit card payments from your clients for any goods and services you offer.</dd>
	
	<dt><a href="<?=SITE_DIR?>services/fiz/credit.php">Personal Loans</a></dt>
	<dd>Whether your funding needs are large or small, our Bank has a loan for you! Fast and easy approval procedures take only 24 hours!</dd>
							
</dl>	
