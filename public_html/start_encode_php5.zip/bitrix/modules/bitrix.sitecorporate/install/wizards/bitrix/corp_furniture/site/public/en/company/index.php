<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("About Us");
?><img height="268" width="400" src="#SITE_DIR#upload/company.jpg" /> 
<p>Furniture Company was founded in 2001 under the idea of designing & manufacturing low-cost, solid-wood furniture.</p>

<p>Our services include design, space planning, hire/lease, repairs and re-upholstery, disposal of second-hand furniture, storage and filing solutions, as well as a selection from the widest range of office furniture to meet all designs and budgets.</p>
 
<p>Our ethos is based entirely on customer service and we listen closely to our client's criteria in all aspects of design, budget and timescale fulfilling them in every way possible.</p>
 
<p>Purchasing furniture is a very important decision for everyone. Please take your time. </p>
 
<p>We look forward to serving you... </p>
 <?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>