<?
$MESS["CSST_TEMPLATE_NAME"] = "Wide";
$MESS["CSST_TEMPLATE_DESC"] = "A light and bright rubber template.";
?>