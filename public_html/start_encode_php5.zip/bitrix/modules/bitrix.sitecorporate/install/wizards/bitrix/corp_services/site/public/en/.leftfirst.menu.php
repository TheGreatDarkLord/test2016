<?
$aMenuLinks = Array(
	Array(
		"Personal", 
		"services/fiz/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Corporate", 
		"services/corp/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>