<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<?
$aMenuLinks = Array(
	Array(
		"Contacts", 
		"contacts/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Login", 
		"login/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>