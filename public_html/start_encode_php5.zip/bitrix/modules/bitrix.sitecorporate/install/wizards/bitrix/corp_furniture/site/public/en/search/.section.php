<?
$sSectionName = "Search";
$arDirProperties = Array(

);
?>