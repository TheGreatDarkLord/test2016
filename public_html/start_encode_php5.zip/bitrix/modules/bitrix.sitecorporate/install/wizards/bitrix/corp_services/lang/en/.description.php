<?
$MESS["PORTAL_WIZARD_NAME"] = "Corporate Service Site";
$MESS["PORTAL_WIZARD_DESC"] = "A corporate site wizard to create a model bank corporate site";
?>