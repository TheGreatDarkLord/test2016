<?
$sSectionName = "Products & Services";
$arDirProperties = Array(

);
?>