<?
$sSectionName = "For Corporate Clients";
$arDirProperties = Array(

);
?>