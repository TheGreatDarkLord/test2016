<?
$MESS["CFST_THEME_PINK"] = "Pink";
?>