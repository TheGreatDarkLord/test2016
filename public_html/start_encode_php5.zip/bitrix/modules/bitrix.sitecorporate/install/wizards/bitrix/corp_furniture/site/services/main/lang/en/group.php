<?
$MESS["REGISTERED_USERS"] = "Registered users";
$MESS["TASK_WIZARD_CONTENT_EDITOR"] = "Edit personal profile. Cache control";
$MESS["TASK_WIZARD_CONTENT_EDITOR_DESC"] = "User can edit own profile and change cache parameters.";
?>