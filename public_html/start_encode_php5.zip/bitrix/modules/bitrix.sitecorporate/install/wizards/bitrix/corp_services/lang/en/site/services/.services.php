<?
$MESS["SERVICE_MAIN_SETTINGS"] = "Site Preferences";
$MESS["SERVICE_IBLOCK"] = "Information Blocks";
?>