<?
$sSectionName = "Contacts";
$arDirProperties = Array(

);
?>