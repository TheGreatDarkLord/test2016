<?
$MESS ['MENU_TREE_NAME'] = "Bottom menu";
$MESS ['MENU_TREE_DESC'] = "Bottom menu";
?>