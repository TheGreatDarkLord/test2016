<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<?
$aMenuLinks = Array(
	Array(
		"About Us", 
		"./", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Designer Profiles", 
		"management.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Mission &amp; Vision", 
		"mission.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"History", 
		"history.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Careers", 
		"vacancies.php", 
		Array(), 
		Array(), 
		"" 
	)
);
?>