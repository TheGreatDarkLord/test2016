<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Bank details");
?>

		<table cellspacing="0" class="data-table">
			<tr class="alt-row">
				<td width="40%">
					<b>Company Name<br />
                      (according to registration documents)</b>
				</td>
				<td>
					Bank
				</td>
			</tr>
			<tr>
				<td>
					<b>Telex</b>
				</td>
				<td>
					XXXXXXX 
				</td>
			</tr>
			<tr class="alt-row">
				<td>
					<b>S.W.I.F.T.</b>
				</td>
				<td>
					XXXXXX
				</td>
			</tr>
			<tr>
				<td>
					<b>SPRINT</b>
				</td>
				<td>
					XX.BANK/XXXX 
				</td>
			</tr>
			<tr class="alt-row">
				<td>
					<b>Telex</b>
				</td>
				<td>
					911156
				</td>
			</tr>
			<tr>
				<td>
					<b>S.W.I.F.T.</b>
				</td>
				<td>
					XXXXXXX
				</td>
			</tr>
			<tr class="alt-row">
				<td>
					<b>SPRINT</b>
				</td>
				<td>
					XXXXXXX.BANK/BITEX
				</td>
			</tr>
			<tr>
				<td>
					<b>Bank Headquarters </b>
				</td>
				<td>
					*** Pine Avenue, Long Beach, CA 90802, USA
				</td>
			</tr>
		</table> 
		

<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>
