<?
$MESS["BCL_MENU_ITEM"] = "Bitrix Cloud Service";
$MESS["BCL_MENU_CONTROL_ITEM"] = "CDN Web Accelerator";
$MESS["BCL_MENU_BACKUP_ITEM"] = "Backups";
$MESS["BCL_MENU_BACKUP_JOB_ITEM"] = "Backup schedule";
$MESS["BCL_MENU_MONITORING_ITEM"] = "Cloud Inspector";
?>