<?
$MESS["BCL_MON_MOB_MENU_TITLE"] = "Bitrix Cloud Service";
$MESS["BCL_MON_MOB_MENU_IPAGE"] = "Cloud Inspector";
$MESS["BCL_MON_MOB_TEST_LICENSE"] = "Bitrix license will expire on";
$MESS["BCL_MON_MOB_IS_HTTPS"] = "Use HTTPS to inspect domain";
$MESS["BCL_MON_MOB_TEST_SSL_CERT_VALIDITY"] = "SSL certificate will expire on";
$MESS["BCL_MON_MOB_TEST_DOMAIN_REGISTRATION"] = "Domain will expire on";
$MESS["BCL_MON_MOB_TEST_HTTP_RESPONSE_TIME"] = "Website response";
$MESS["BCL_MON_MOB_INSPECTOR"] = "Website Inspector";
$MESS["BCL_MON_MOB_SUBSCRIBE"] = "Receive notifications";
$MESS["BCL_MON_MOB_MENU_PUSH"] = "Configure PUSH notifications";
?>