<?
$MESS["BCL_BACKUP_WS_SERVER"] = "Error sending request to the backup server (code: #STATUS#).";
$MESS["BCL_BACKUP_WRONG_TIME"] = "The backup start time is incorrect.";
$MESS["BCL_BACKUP_WRONG_URL"] = "The backup URL is incorrect.";
$MESS["BCL_BACKUP_WRONG_WEEKDAYS"] = "The days for weekly backup are incorrect.";
$MESS["BCL_BACKUP_EMPTY_SECRET_KEY"] = "The backup key is not specified.";
?>