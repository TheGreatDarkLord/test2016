<?
$MESS["GD_BITRIXCLOUD_MONITOR_NAME"] = "Cloud Inspector";
$MESS["GD_BITRIXCLOUD_MONITOR_DESC"] = "Cloud Inspector";
?>