<?
$arModuleVersion = array(
	"VERSION" => "16.0.0",
	"VERSION_DATE" => "2015-12-24 11:40:00",
);
?>