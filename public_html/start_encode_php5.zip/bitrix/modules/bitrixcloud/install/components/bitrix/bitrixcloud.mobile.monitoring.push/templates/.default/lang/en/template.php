<?
$MESS["BCMMP_TITLE"] = "Website Inspector";
$MESS["BCMMP_TITLE2"] = "Configure PUSH notifications";
$MESS["BCMMP_DOMAINS_TITLE"] = "Domains";
$MESS["BCMMP_BACK"] = "Back";
$MESS["BCMMP_SAVE"] = "Save";
$MESS["BCMMP_PUSH_RECIEVE"] = "Receive notifications";
$MESS["BCMMP_JS_SAVING"] = "Saving...";
$MESS["BCMMP_JS_SAVE_ERROR"] = "Cannot save because an error occurred.";
$MESS["BCMMP_ON"] = "Enable";
$MESS["BCMMP_OFF"] = "Disable";
$MESS["BCMMP_NO_DOMAINS"] = "No domains configured";
?>