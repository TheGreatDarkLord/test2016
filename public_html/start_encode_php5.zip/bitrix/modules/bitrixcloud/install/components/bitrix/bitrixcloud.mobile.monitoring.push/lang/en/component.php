<?
$MESS["BCMMP_ACCESS_DENIED"] = "Access denied";
$MESS["BCMMP_BC_NOT_INSTALLED"] = "The Bitrix Cloud module is not installed.";
$MESS["BCMMP_MA_NOT_INSTALLED"] = "The Mobile Builder module is not installed.";
?>