<?
$MESS["BCMMP_MOBILEAPP_NOT_INSTALLED"] = "The mobileapp module is not installed.";
$MESS["BCMMP_ACCESS_DENIED"] = "Access denied";
$MESS["BCMMP_BC_NOT_INSTALLED"] = "The Bitrix Cloud module is not installed.";
$MESS["BCMMP_SAVE_OPTS_ERROR"] = "Could not save data.";
?>