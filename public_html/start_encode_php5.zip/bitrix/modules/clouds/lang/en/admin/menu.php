<?
$MESS["CLO_MENU_ITEM"] = "Cloud Storages";
$MESS["CLO_MENU_TITLE"] = "Manage Cloud Storages";
?>