<?
$MESS["CLO_STORAGE_SELECTEL_EDIT_USER"] = "User name (API user)";
$MESS["CLO_STORAGE_SELECTEL_EDIT_KEY"] = "Access key (API key)";
$MESS["CLO_STORAGE_SELECTEL_EDIT_HOST"] = "Server name (API host)";
?>