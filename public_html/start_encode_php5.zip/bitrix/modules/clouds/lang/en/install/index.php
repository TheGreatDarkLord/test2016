<?
$MESS["CLO_MODULE_NAME"] = "Cloud Storages";
$MESS["CLO_MODULE_DESCRIPTION"] = "Supports cloud file storages.";
$MESS["CLO_INSTALL_TITLE"] = "Cloud Storages Module Installation";
$MESS["CLO_UNINSTALL_TITLE"] = "Cloud Storages Module Uninstallation";
?>