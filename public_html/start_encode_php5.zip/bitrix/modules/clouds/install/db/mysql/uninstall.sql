DROP TABLE if exists b_clouds_file_upload;
DROP TABLE if exists b_clouds_file_bucket;
DROP TABLE if exists b_clouds_file_resize;
